var express=require("express");
var myapp=express();
myapp.get("/",function (req,res) {
    res.send("welcome to my app")
})
myapp.get("/greetings",function (req,res) {
    let person=req.query.person;
    res.send(`welcome , ${person} !`)
})
myapp.get("/travel",function (req,res) {
    let from=req.query.from;
    let to=req.query.to;
    res.send(`${from} to ${to} `)
})
myapp.get("/travel/:place",function (req,res) {
    let place=req.params.place;
    res.send(`${place} `)
})
myapp.get("/travel/:place1/:place2",function (req,res) {
    let place1=req.params.place1;
    let place2=req.params.place2;

    res.send(`${place1} to ${place2} `)
})



myapp.listen(8000,function () {
    console.log("success");
})


